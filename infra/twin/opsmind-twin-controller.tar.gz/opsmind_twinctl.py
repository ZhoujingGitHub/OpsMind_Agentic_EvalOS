#!/usr/bin/env python3
"""Deterministic control plane for the OpsMind M2 protocol Twin.

The script manages only frozen scenarios. It never accepts shell commands,
paths, service names or packet-filter expressions from a caller. The evaluated
Agent sees read-only observations through EvalOS MCP tools; prepare/reset stay
inside the trusted Harness boundary.
"""

from __future__ import annotations

import base64
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path("/srv/opsmind-twin")
CONFIG_ROOT = ROOT / "config"
BASELINE_ROOT = CONFIG_ROOT / "baseline"
ACTIVE_ROOT = CONFIG_ROOT / "active"
TRIAL_ROOT = ROOT / "trials"
PCAP_ROOT = ROOT / "pcap"
RUNTIME_ROOT = Path("/run/opsmind-twin")
STATE_FILE = RUNTIME_ROOT / "active.json"
LOCK_FILE = Path("/run/lock/opsmind-twin.lock")
UERANSIM_ROOT = ROOT / "vendor" / "UERANSIM-3.2.7"
GNB_BINARY = UERANSIM_ROOT / "build" / "nr-gnb"
UE_BINARY = UERANSIM_ROOT / "build" / "nr-ue"
DBCTL_CANDIDATES = [
    Path("/usr/local/bin/open5gs-dbctl"),
    Path("/usr/share/open5gs/db/open5gs-dbctl"),
    Path("/usr/bin/open5gs-dbctl"),
]
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

IMSI = "999700000000001"
KEY = "465B5CE8B199B49FAA5F0A2EE238A6BC"
OPC = "E8ED289DEBA952E4283B54E88E6183CA"
DNN = "internet"
CORE_SERVICES = [
    "open5gs-nrfd", "open5gs-scpd", "open5gs-amfd", "open5gs-smfd", "open5gs-upfd",
    "open5gs-ausfd", "open5gs-udmd", "open5gs-udrd", "open5gs-pcfd", "open5gs-nssfd", "open5gs-bsfd",
]

SCENARIO_EVIDENCE = {
    "subscriber-missing": ["log:amf-unknown-supi", "state:subscriber-absent", "pcap:ngap-observed"],
    "subscriber-key-mismatch": ["log:ausf-authentication-failure", "state:subscriber-present", "pcap:ngap-observed"],
    "unknown-dnn": ["log:amf-dnn-not-supported", "state:ue-registered", "pcap:ngap-observed"],
    "slice-mismatch": ["log:gnb-amf-selection-failed", "state:allowed-nssai-mismatch", "pcap:ngap-observed"],
    "tracking-area-mismatch": ["log:amf-tai-not-served", "state:gnb-sctp-connected", "pcap:ngap-observed"],
    "amf-process-down": ["process:open5gs-amfd-inactive", "probe:sctp-38412-refused", "log:gnb-amf-connect-failed"],
    "smf-process-down": ["process:open5gs-smfd-inactive", "state:ue-registered", "log:amf-smf-discovery-failed"],
    "upf-process-down": ["process:open5gs-upfd-inactive", "probe:user-plane-failed", "log:smf-pfcp-association-lost"],
    "nrf-process-down": ["process:open5gs-nrfd-inactive", "log:nf-discovery-failed", "metric:nrf-registration-zero"],
    "mongodb-process-down": ["process:mongod-inactive", "log:udr-subscriber-query-failed", "state:subscriber-query-unavailable", "pcap:ngap-observed"],
    "sctp-blocked": ["process:amf-healthy", "pcap:sctp-observed", "state:firewall-sctp-drop"],
    "pfcp-blocked": ["process:smf-upf-healthy", "pcap:pfcp-observed", "state:firewall-pfcp-drop"],
    "gtpu-blocked": ["state:pdu-session-active", "pcap:gtp-observed", "state:firewall-gtpu-drop"],
    "n6-route-missing": ["state:pdu-session-active", "probe:ue-tunnel-present", "state:n6-route-missing"],
    "dns-blocked": ["probe:ip-connectivity-ok", "probe:dns-resolution-failed", "state:dns-drop-rule"],
    "user-plane-latency": ["metric:user-plane-rtt-high", "state:tc-delay-active", "probe:packet-loss-low"],
    "gnb-process-crash": ["process:ueransim-gnb-inactive", "process:open5gs-core-healthy", "log:gnb-process-exit"],
    "observability-gap": ["error:amf-log-source-unavailable", "state:protocol-symptom-ambiguous"],
    "stale-alarm": ["alert:amf-down-stale", "process:amf-healthy", "probe:registration-success"],
    "pcap-capacity-risk": ["metric:pcap-growth-high", "state:disk-current-safe", "forecast:disk-threshold-breach"],
}

PREFIX_BY_CAPABILITY = {
    "health": {"state", "process", "alert"},
    "logs": {"log", "error", "alert"},
    "sessions": {"state"},
    "processes": {"process"},
    "pcap_summary": {"pcap"},
    "connectivity": {"probe"},
    "subscriber": {"state"},
    "metrics": {"metric", "forecast", "state"},
}


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def digest(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def run(args: list[str], *, check: bool = False, timeout: int = 30, capture: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(args, check=check, timeout=timeout, text=True,
                          stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                          stderr=subprocess.STDOUT if capture else subprocess.DEVNULL)


def service_active(name: str) -> bool:
    return run(["systemctl", "is-active", "--quiet", name]).returncode == 0


def load_state() -> dict | None:
    if not STATE_FILE.exists():
        return None
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def save_state(state: dict) -> None:
    RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
    temporary = STATE_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(STATE_FILE)


def stop_pid(pid_file: Path) -> None:
    if not pid_file.exists():
        return
    try:
        pid = int(pid_file.read_text().strip())
        os.killpg(pid, signal.SIGTERM)
        time.sleep(0.6)
        try:
            os.killpg(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    except (ValueError, ProcessLookupError):
        pass
    pid_file.unlink(missing_ok=True)


def ensure_ogstun() -> None:
    run(["modprobe", "tun"])
    if run(["ip", "link", "show", "ogstun"]).returncode != 0:
        run(["ip", "tuntap", "add", "name", "ogstun", "mode", "tun"], check=True)
    run(["ip", "addr", "replace", "10.45.0.1/16", "dev", "ogstun"], check=True)
    run(["ip", "link", "set", "ogstun", "up"], check=True)
    run(["sysctl", "-w", "net.ipv4.ip_forward=1"], check=True)
    if run(["iptables", "-t", "nat", "-C", "POSTROUTING", "-s", "10.45.0.0/16", "!", "-o", "ogstun", "-j", "MASQUERADE"]).returncode != 0:
        run(["iptables", "-t", "nat", "-A", "POSTROUTING", "-s", "10.45.0.0/16", "!", "-o", "ogstun", "-j", "MASQUERADE"], check=True)
    ensure_forwarding()
    ensure_dn()
    ensure_ue_namespace()


def ensure_forwarding() -> None:
    chain = "OPSMIND_TWIN_BASE"
    if run(["iptables", "-L", chain, "-n"]).returncode != 0:
        run(["iptables", "-N", chain], check=True)
    while run(["iptables", "-C", "FORWARD", "-j", chain]).returncode == 0:
        run(["iptables", "-D", "FORWARD", "-j", chain], check=True)
    run(["iptables", "-I", "FORWARD", "2", "-j", chain], check=True)
    run(["iptables", "-F", chain], check=True)
    run(["iptables", "-A", chain, "-s", "10.45.0.0/16", "-j", "ACCEPT"], check=True)
    run(["iptables", "-A", chain, "-d", "10.45.0.0/16", "-j", "ACCEPT"], check=True)


def ensure_dn() -> None:
    if "opsmind-dn" not in (run(["ip", "netns", "list"]).stdout or ""):
        run(["ip", "netns", "add", "opsmind-dn"], check=True)
    if run(["ip", "link", "show", "opsminddn0"]).returncode != 0:
        run(["ip", "link", "add", "opsminddn0", "type", "veth", "peer", "name", "dn0",
             "netns", "opsmind-dn"], check=True)
    run(["ip", "addr", "replace", "10.46.0.1/24", "dev", "opsminddn0"], check=True)
    run(["ip", "link", "set", "opsminddn0", "up"], check=True)
    run(["ip", "-n", "opsmind-dn", "addr", "replace", "10.46.0.53/24", "dev", "dn0"], check=True)
    run(["ip", "-n", "opsmind-dn", "link", "set", "dn0", "up"], check=True)
    run(["ip", "-n", "opsmind-dn", "link", "set", "lo", "up"], check=True)
    run(["ip", "-n", "opsmind-dn", "route", "replace", "10.45.0.0/16", "via", "10.46.0.1",
         "dev", "dn0"], check=True)
    run(["ip", "route", "replace", "10.46.0.0/24", "dev", "opsminddn0", "src", "10.46.0.1"], check=True)


def dn_route_present() -> bool:
    result = run(["ip", "route", "show", "10.46.0.0/24"])
    return result.returncode == 0 and "opsminddn0" in (result.stdout or "")


def ensure_ue_namespace() -> None:
    if "opsmind-ue" not in (run(["ip", "netns", "list"]).stdout or ""):
        run(["ip", "netns", "add", "opsmind-ue"], check=True)
    if run(["ip", "link", "show", "opsmindue0"]).returncode != 0:
        run(["ip", "link", "add", "opsmindue0", "type", "veth", "peer", "name", "ue0",
             "netns", "opsmind-ue"], check=True)
    run(["ip", "addr", "replace", "10.47.0.1/30", "dev", "opsmindue0"], check=True)
    run(["ip", "link", "set", "opsmindue0", "up"], check=True)
    run(["ip", "-n", "opsmind-ue", "addr", "replace", "10.47.0.2/30", "dev", "ue0"], check=True)
    run(["ip", "-n", "opsmind-ue", "link", "set", "ue0", "up"], check=True)
    run(["ip", "-n", "opsmind-ue", "link", "set", "lo", "up"], check=True)


def ensure_fault_chains() -> None:
    for table, parent, chain in [
        ("filter", "INPUT", "OPSMIND_TWIN_IN"),
        ("filter", "OUTPUT", "OPSMIND_TWIN_OUT"),
        ("filter", "FORWARD", "OPSMIND_TWIN_FWD"),
    ]:
        prefix = ["iptables"] if table == "filter" else ["iptables", "-t", table]
        if run(prefix + ["-L", chain, "-n"]).returncode != 0:
            run(prefix + ["-N", chain], check=True)
        if run(prefix + ["-C", parent, "-j", chain]).returncode != 0:
            run(prefix + ["-I", parent, "1", "-j", chain], check=True)
        run(prefix + ["-F", chain], check=True)


def dbctl() -> Path:
    for candidate in DBCTL_CANDIDATES:
        if candidate.exists():
            return candidate
    raise RuntimeError("open5gs-dbctl was not installed")


def restore_subscriber() -> None:
    run([str(dbctl()), "remove", IMSI], timeout=60)
    added = run([str(dbctl()), "add", IMSI, KEY, OPC], timeout=60)
    if added.returncode != 0:
        fallback = run([str(dbctl()), "add_ue_with_slice", IMSI, KEY, OPC, DNN, "1", "000001"], timeout=60)
        if fallback.returncode != 0:
            raise RuntimeError(f"subscriber restore failed: {(added.stdout or fallback.stdout)[-500:]}")


def remove_subscriber() -> None:
    for _ in range(3):
        removed = run([str(dbctl()), "remove", IMSI], timeout=60)
        if removed.returncode != 0:
            time.sleep(0.5)
            continue
        time.sleep(0.5)
        if subscriber_view().get("present") is False:
            return
    raise RuntimeError("subscriber removal did not become visible in MongoDB")


def start_core() -> None:
    run(["systemctl", "enable", "--now", "mongod"], check=True, timeout=90)
    for service in CORE_SERVICES:
        run(["systemctl", "restart", service], check=True, timeout=45)
    time.sleep(2)


def reset_faults() -> None:
    ensure_fault_chains()
    run(["tc", "qdisc", "del", "dev", "ogstun", "root"])
    run(["sysctl", "-w", "net.ipv4.ip_forward=1"])


def stop_runtime(state: dict | None) -> None:
    if not state:
        return
    trial_dir = Path(state.get("trial_dir", ""))
    if trial_dir.is_relative_to(TRIAL_ROOT):
        for name in ["ue.pid", "gnb.pid", "pcap.pid", "dns.pid"]:
            stop_pid(trial_dir / name)


def fault_chains_clean() -> bool:
    for chain in ["OPSMIND_TWIN_IN", "OPSMIND_TWIN_OUT", "OPSMIND_TWIN_FWD"]:
        result = run(["iptables", "-S", chain])
        if result.returncode != 0:
            return False
        rules = [line for line in (result.stdout or "").splitlines() if line.startswith("-A ")]
        if rules:
            return False
    return True


def baseline_verification() -> dict[str, bool]:
    subscriber = subscriber_view()
    return {
        "all_core_services_active": all(service_active(item) for item in ["mongod", *CORE_SERVICES]),
        "fault_chains_empty": fault_chains_clean(),
        "traffic_delay_absent": not tc_delay_active(),
        "ip_forward_enabled": Path("/proc/sys/net/ipv4/ip_forward").read_text().strip() == "1",
        "ogstun_up": run(["ip", "link", "show", "up", "dev", "ogstun"]).returncode == 0,
        "baseline_subscriber_present": subscriber.get("present") is True,
        "ue_forwarding_rules_present": (
            firewall_has(["OPSMIND_TWIN_BASE", "10.45.0.0/16", "ACCEPT"])
            and run(["iptables", "-t", "nat", "-C", "POSTROUTING", "-s", "10.45.0.0/16",
                     "!", "-o", "ogstun", "-j", "MASQUERADE"]).returncode == 0
        ),
        "isolated_dn_ready": dn_route_present() and "opsmind-dn" in (run(["ip", "netns", "list"]).stdout or ""),
        "isolated_ue_ready": "opsmind-ue" in (run(["ip", "netns", "list"]).stdout or ""),
    }


def reset_baseline(state: dict | None = None) -> dict:
    stop_runtime(state)
    reset_faults()
    ensure_ogstun()
    start_core()
    restore_subscriber()
    verification = baseline_verification()
    clean = all(verification.values())
    return {"ok": clean, "clean": clean, "baseline_ref": "opsmind-m2-baseline-v1",
            "verification": verification, "at": now()}


def copy_active_configs(scenario: str) -> tuple[Path, Path]:
    ACTIVE_ROOT.mkdir(parents=True, exist_ok=True)
    gnb_text = (BASELINE_ROOT / "gnb.yaml").read_text(encoding="utf-8")
    ue_text = (BASELINE_ROOT / "ue.yaml").read_text(encoding="utf-8")
    if scenario == "subscriber-key-mismatch":
        ue_text = ue_text.replace(KEY, "00000000000000000000000000000000")
    elif scenario == "unknown-dnn":
        ue_text = ue_text.replace("apn: 'internet'", "apn: 'factory-bad'")
    elif scenario == "slice-mismatch":
        ue_text = ue_text.replace("sst: 1", "sst: 2")
    elif scenario == "tracking-area-mismatch":
        gnb_text = gnb_text.replace("tac: 1", "tac: 7")
    gnb_path = ACTIVE_ROOT / "gnb.yaml"
    ue_path = ACTIVE_ROOT / "ue.yaml"
    gnb_path.write_text(gnb_text, encoding="utf-8")
    ue_path.write_text(ue_text, encoding="utf-8")
    return gnb_path, ue_path


def spawn_to_log(args: list[str], log_path: Path, pid_path: Path) -> int:
    output = log_path.open("ab", buffering=0)
    process = subprocess.Popen(args, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    pid_path.write_text(str(process.pid), encoding="ascii")
    return process.pid


def start_protocol_runtime(state: dict, gnb_path: Path, ue_path: Path) -> None:
    trial_dir = Path(state["trial_dir"])
    spawn_to_log(["ip", "netns", "exec", "opsmind-dn", "python3",
                  "/usr/local/libexec/opsmind-twin-dns.py"], trial_dir / "dns.log", trial_dir / "dns.pid")
    spawn_to_log(["tcpdump", "-Z", "root", "-i", "any", "-s", "0", "-C", "25", "-W", "4",
                  "-w", str(Path(state["pcap_dir"]) / "capture.pcap")],
                 trial_dir / "tcpdump.log", trial_dir / "pcap.pid")
    spawn_to_log([str(GNB_BINARY), "-c", str(gnb_path)], trial_dir / "gnb.log", trial_dir / "gnb.pid")
    time.sleep(1.5)
    spawn_to_log(["ip", "netns", "exec", "opsmind-ue", str(UE_BINARY), "-c", str(ue_path)],
                 trial_dir / "ue.log", trial_dir / "ue.pid")


def inject_fault(scenario: str, state: dict) -> None:
    if scenario == "subscriber-missing":
        remove_subscriber()
    elif scenario == "amf-process-down":
        run(["systemctl", "stop", "open5gs-amfd"], check=True)
    elif scenario == "smf-process-down":
        run(["systemctl", "stop", "open5gs-smfd"], check=True)
    elif scenario == "upf-process-down":
        run(["systemctl", "stop", "open5gs-upfd"], check=True)
    elif scenario == "nrf-process-down":
        run(["systemctl", "stop", "open5gs-nrfd"], check=True)
    elif scenario == "mongodb-process-down":
        run(["systemctl", "stop", "mongod"], check=True)
    elif scenario == "sctp-blocked":
        run(["iptables", "-A", "OPSMIND_TWIN_IN", "-p", "sctp", "--dport", "38412", "-j", "DROP"], check=True)
    elif scenario == "pfcp-blocked":
        run(["iptables", "-A", "OPSMIND_TWIN_IN", "-p", "udp", "--dport", "8805", "-j", "DROP"], check=True)
    elif scenario == "gtpu-blocked":
        run(["iptables", "-A", "OPSMIND_TWIN_IN", "-p", "udp", "--dport", "2152", "-j", "DROP"], check=True)
    elif scenario == "n6-route-missing":
        run(["ip", "route", "del", "10.46.0.0/24"], check=True)
    elif scenario == "dns-blocked":
        run(["iptables", "-A", "OPSMIND_TWIN_FWD", "-s", "10.45.0.0/16", "-p", "udp", "--dport", "53", "-j", "DROP"], check=True)
    elif scenario == "user-plane-latency":
        run(["tc", "qdisc", "add", "dev", "ogstun", "root", "netem", "delay", "250ms", "20ms"], check=True)
    state["fault_injected_at"] = now()


def prepare(request: dict) -> dict:
    trial_id, scenario = request["trial_id"], request["scenario_id"]
    if scenario not in SCENARIO_EVIDENCE:
        return {"ok": False, "operation": "prepare", "error": "unknown frozen scenario"}
    current = load_state()
    if current and current.get("trial_id") != trial_id:
        return {"ok": False, "operation": "prepare", "error": "another Trial is active"}
    if current:
        return {"ok": False, "operation": "prepare", "error": "Trial is already prepared"}
    reset = reset_baseline()
    if not reset["ok"]:
        return {"ok": False, "operation": "prepare", "error": "baseline reset failed",
                "verification": reset["verification"]}
    trial_dir = (TRIAL_ROOT / trial_id).resolve()
    pcap_dir = (PCAP_ROOT / trial_id).resolve()
    if not trial_dir.is_relative_to(TRIAL_ROOT.resolve()) or not pcap_dir.is_relative_to(PCAP_ROOT.resolve()):
        return {"ok": False, "operation": "prepare", "error": "Trial path escaped root"}
    trial_dir.mkdir(parents=True, exist_ok=False)
    pcap_dir.mkdir(parents=True, exist_ok=False)
    gnb_path, ue_path = copy_active_configs(scenario)
    log_offsets = {name: Path(f"/var/log/open5gs/{name}.log").stat().st_size
                   if Path(f"/var/log/open5gs/{name}.log").exists() else 0
                   for name in ["amf", "smf", "upf", "nrf", "udr", "ausf", "nssf"]}
    state = {"trial_id": trial_id, "scenario_id": scenario, "seed": int(request.get("seed", 0)),
             "trial_dir": str(trial_dir), "pcap_dir": str(pcap_dir), "log_offsets": log_offsets,
             "prepared_at": now()}
    save_state(state)
    try:
        inject_fault(scenario, state)
        start_protocol_runtime(state, gnb_path, ue_path)
        time.sleep(7)
        if scenario == "gnb-process-crash":
            stop_pid(trial_dir / "gnb.pid")
        state["evidence_cache"] = sorted(observed_evidence(state))
        save_state(state)
    except Exception:
        reset_baseline(state)
        STATE_FILE.unlink(missing_ok=True)
        raise
    fingerprint = digest({"scenario": scenario, "seed": state["seed"], "baseline": "opsmind-m2-baseline-v1",
                          "components": {"open5gs": "2.8.0", "mongodb": "8.0.29", "ueransim": "3.2.7"}})
    state["fingerprint"] = fingerprint
    save_state(state)
    return {"ok": True, "operation": "prepare", "isolation": "serial-host-runtime+dedicated-artifact-namespace",
            "fingerprint": fingerprint, "prepared_at": state["prepared_at"]}


def require_active(request: dict) -> dict:
    state = load_state()
    if not state or state.get("trial_id") != request.get("trial_id"):
        raise PermissionError("requested Trial is not active")
    return state


def tail(path: Path, limit: int = 80) -> list[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]


def pid_active(pid_file: Path) -> bool:
    if not pid_file.exists():
        return False
    try:
        os.kill(int(pid_file.read_text().strip()), 0)
        return True
    except (ValueError, ProcessLookupError, PermissionError):
        return False


def process_view(state: dict) -> dict:
    trial_dir = Path(state["trial_dir"])
    return {
        "services": {name: service_active(name) for name in ["mongod", *CORE_SERVICES]},
        "ueransim": {name: pid_active(trial_dir / f"{name}.pid") for name in ["gnb", "ue"]},
    }


def session_view(state: dict) -> dict:
    ue_log = "\n".join(tail(Path(state["trial_dir"]) / "ue.log", 120))
    return {
        "ue_registered": "Registration accept" in ue_log or "RM-REGISTERED" in ue_log,
        "pdu_session_established": "PDU Session Establishment Accept" in ue_log or "PDU session establishment is successful" in ue_log,
        "ue_tunnel_present": run(["ip", "-n", "opsmind-ue", "link", "show", "uesimtun0"]).returncode == 0,
    }


def subscriber_view() -> dict:
    if not service_active("mongod"):
        return {"available": False, "reason": "mongod inactive"}
    script = ("const x=db.subscribers.findOne({imsi:'%s'}); "
              "print(JSON.stringify(x?{imsi:x.imsi,slices:x.slice.map(s=>({sst:s.sst,sd:s.sd,dnns:s.session.map(v=>v.name)}))}:null))") % IMSI
    result = run(["mongosh", "open5gs", "--quiet", "--eval", script], timeout=20)
    raw = (result.stdout or "").strip().splitlines()
    try:
        record = json.loads(raw[-1]) if raw else None
    except json.JSONDecodeError:
        record = None
    return {"available": result.returncode == 0, "present": record is not None, "record": record}


def pcap_view(state: dict) -> dict:
    files = sorted(Path(state["pcap_dir"]).glob("capture.pcap*"))
    size = sum(item.stat().st_size for item in files)
    counts = {}
    if files and files[0].stat().st_size > 24:
        for protocol, display_filter in [("sctp", "sctp"), ("ngap", "ngap"), ("pfcp", "pfcp"), ("gtp", "gtp")]:
            result = run(["tshark", "-r", str(files[0]), "-Y", display_filter, "-T", "fields", "-e", "frame.number"], timeout=20)
            counts[protocol] = len([line for line in (result.stdout or "").splitlines() if line.strip()])
    return {"files": len(files), "bytes": size, "protocol_frames": counts}


def connectivity_view(state: dict) -> dict:
    session = session_view(state)
    if not session["ue_tunnel_present"]:
        return {"tunnel": False, "ping_dn": False, "dns": False, "rtt_avg_ms": None, "loss_pct": 100.0}
    ping = run(["ip", "netns", "exec", "opsmind-ue", "ping", "-I", "uesimtun0", "-c", "2",
                "-W", "2", "10.46.0.53"], timeout=8)
    output = ping.stdout or ""
    rtt = re.search(r"=\s*[\d.]+/([\d.]+)/", output)
    loss = re.search(r"([\d.]+)% packet loss", output)
    return {"tunnel": True, "ping_dn": ping.returncode == 0, "dns": dns_probe(),
            "rtt_avg_ms": float(rtt.group(1)) if rtt else None,
            "loss_pct": float(loss.group(1)) if loss else 100.0,
            "ip_forward": Path("/proc/sys/net/ipv4/ip_forward").read_text().strip() == "1"}


def dns_probe() -> bool:
    return run(["ip", "netns", "exec", "opsmind-ue", "python3",
                "/usr/local/libexec/opsmind-twin-dns-probe.py"], timeout=8).returncode == 0


def metrics_view(state: dict) -> dict:
    usage = shutil.disk_usage(ROOT)
    pcap_bytes = sum(item.stat().st_size for item in Path(state["pcap_dir"]).glob("capture.pcap*"))
    return {"disk_total_bytes": usage.total, "disk_used_bytes": usage.used, "disk_percent": round(usage.used / usage.total * 100, 2),
            "pcap_bytes": pcap_bytes, "load_average": list(os.getloadavg()),
            "pcap_forecast_threshold_percent": 80 if state["scenario_id"] == "pcap-capacity-risk" else None}


def tail_after(path: Path, offset: int, limit: int = 100) -> list[str]:
    if not path.exists():
        return []
    with path.open("rb") as source:
        size = path.stat().st_size
        source.seek(offset if 0 <= offset <= size else 0)
        content = source.read().decode("utf-8", errors="replace")
    return content.splitlines()[-limit:]


def core_logs(state: dict) -> dict:
    offsets = state.get("log_offsets", {})
    return {name: tail_after(Path(f"/var/log/open5gs/{name}.log"), int(offsets.get(name, 0)), 100)
            for name in ["amf", "smf", "upf", "nrf", "udr", "ausf", "nssf"]}


def firewall_has(parts: list[str]) -> bool:
    result = run(["iptables", "-S"])
    text = result.stdout or ""
    return result.returncode == 0 and all(part in text for part in parts)


def tc_delay_active() -> bool:
    result = run(["tc", "qdisc", "show", "dev", "ogstun"])
    return result.returncode == 0 and "netem" in (result.stdout or "")


def observed_evidence(state: dict) -> set[str]:
    """Issue evidence identifiers only after their backing observation exists."""
    scenario = state["scenario_id"]
    processes = process_view(state)
    sessions = session_view(state)
    subscriber = subscriber_view()
    connectivity = connectivity_view(state)
    pcap = pcap_view(state)
    logs = core_logs(state)
    trial_dir = Path(state["trial_dir"])
    log_text = "\n".join(
        tail(trial_dir / "gnb.log", 160) + tail(trial_dir / "ue.log", 160)
        + [line for values in logs.values() for line in values]
    ).lower()
    frames = pcap.get("protocol_frames", {})
    supported: set[str] = set()

    if scenario == "subscriber-missing" and subscriber.get("present") is False:
        supported.add("state:subscriber-absent")
    if scenario == "subscriber-key-mismatch" and subscriber.get("present") is True:
        supported.add("state:subscriber-present")
    if scenario in {"unknown-dnn", "smf-process-down"} and sessions["ue_registered"]:
        supported.add("state:ue-registered")
    if scenario == "slice-mismatch":
        supported.add("state:allowed-nssai-mismatch")
    if scenario == "tracking-area-mismatch" and frames.get("sctp", 0) > 0:
        supported.add("state:gnb-sctp-connected")
    if scenario == "amf-process-down" and not processes["services"]["open5gs-amfd"]:
        supported.update({"process:open5gs-amfd-inactive", "probe:sctp-38412-refused"})
    if scenario == "smf-process-down" and not processes["services"]["open5gs-smfd"]:
        supported.add("process:open5gs-smfd-inactive")
    if scenario == "upf-process-down" and not processes["services"]["open5gs-upfd"]:
        supported.update({"process:open5gs-upfd-inactive", "probe:user-plane-failed"})
    if scenario == "nrf-process-down" and not processes["services"]["open5gs-nrfd"]:
        supported.update({"process:open5gs-nrfd-inactive", "metric:nrf-registration-zero"})
    if scenario == "mongodb-process-down" and not processes["services"]["mongod"]:
        supported.update({"process:mongod-inactive", "state:subscriber-query-unavailable"})
    if scenario == "sctp-blocked" and firewall_has(["OPSMIND_TWIN_IN", "sctp", "38412", "DROP"]):
        supported.update({"process:amf-healthy", "state:firewall-sctp-drop"})
    if scenario == "pfcp-blocked" and firewall_has(["OPSMIND_TWIN_IN", "udp", "8805", "DROP"]):
        supported.update({"process:smf-upf-healthy", "state:firewall-pfcp-drop"})
    if scenario == "gtpu-blocked" and firewall_has(["OPSMIND_TWIN_IN", "udp", "2152", "DROP"]):
        supported.add("state:firewall-gtpu-drop")
    if sessions["pdu_session_established"]:
        if scenario in {"gtpu-blocked", "n6-route-missing"}:
            supported.add("state:pdu-session-active")
    if scenario == "n6-route-missing" and not dn_route_present():
        if sessions["ue_tunnel_present"]:
            supported.add("probe:ue-tunnel-present")
        supported.add("state:n6-route-missing")
    if scenario == "dns-blocked" and firewall_has(["OPSMIND_TWIN_FWD", "udp", "53", "DROP"]):
        supported.add("state:dns-drop-rule")
        if connectivity.get("ping_dn") and not connectivity.get("dns"):
            supported.update({"probe:ip-connectivity-ok", "probe:dns-resolution-failed"})
    if scenario == "user-plane-latency" and tc_delay_active():
        supported.add("state:tc-delay-active")
        if (connectivity.get("rtt_avg_ms") or 0) >= 200:
            supported.add("metric:user-plane-rtt-high")
        if connectivity.get("loss_pct", 100) < 50:
            supported.add("probe:packet-loss-low")
    if scenario == "gnb-process-crash" and not processes["ueransim"]["gnb"]:
        supported.update({"process:ueransim-gnb-inactive", "log:gnb-process-exit"})
        if all(processes["services"].values()):
            supported.add("process:open5gs-core-healthy")
    if scenario == "observability-gap":
        supported.update({"error:amf-log-source-unavailable", "state:protocol-symptom-ambiguous"})
    if scenario == "stale-alarm" and processes["services"]["open5gs-amfd"]:
        supported.update({"alert:amf-down-stale", "process:amf-healthy"})
        if sessions["ue_registered"]:
            supported.add("probe:registration-success")
    if scenario == "pcap-capacity-risk":
        supported.update({"metric:pcap-growth-high", "state:disk-current-safe", "forecast:disk-threshold-breach"})

    log_patterns = {
        "subscriber-missing": ["unknown", "supi"],
        "subscriber-key-mismatch": ["authentication", "fail"],
        "unknown-dnn": ["requested dnn", "not supported"],
        "slice-mismatch": ["amf selection", "failed"],
        "tracking-area-mismatch": ["ng setup", "fail"],
        "amf-process-down": ["connection refused"],
        "smf-process-down": ["smf", "discover"],
        "upf-process-down": ["pfcp", "association"],
        "nrf-process-down": ["nrf", "fail"],
        "mongodb-process-down": ["cannot find supi", "db"],
    }
    log_refs = [item for item in SCENARIO_EVIDENCE[scenario] if item.startswith("log:")]
    patterns = log_patterns.get(scenario)
    if log_refs and patterns and all(pattern in log_text for pattern in patterns):
        supported.update(log_refs)
    pcap_refs = [item for item in SCENARIO_EVIDENCE[scenario] if item.startswith("pcap:")]
    protocol_refs = {
        "pcap:ngap-observed": frames.get("ngap", 0) > 0,
        "pcap:sctp-observed": frames.get("sctp", 0) > 0,
        "pcap:pfcp-observed": frames.get("pfcp", 0) > 0,
        "pcap:gtp-observed": frames.get("gtp", 0) > 0,
    }
    supported.update(item for item in pcap_refs if protocol_refs.get(item, False))
    return supported


def evidence_for(state: dict, capability: str) -> list[str]:
    scenario = state["scenario_id"]
    prefixes = PREFIX_BY_CAPABILITY[capability]
    # prepare() waits for protocol convergence and captures an immutable evidence
    # snapshot once. Reusing it keeps repeated read-only tools consistent and
    # avoids rerunning tshark, mongosh, DNS and ping for every capability.
    observed = set(state.get("evidence_cache") or observed_evidence(state))
    return [item for item in SCENARIO_EVIDENCE[scenario]
            if item in observed and item.split(":", 1)[0] in prefixes]


def observe(request: dict) -> dict:
    state = require_active(request)
    capability = request["capability"]
    if capability not in PREFIX_BY_CAPABILITY:
        return {"ok": False, "operation": "observe", "error": {"code": "CAPABILITY_DENIED", "message": "unknown capability"}}
    if state["scenario_id"] == "observability-gap" and capability == "logs":
        return {"ok": False, "operation": "observe",
                "error": {"code": "SOURCE_UNAVAILABLE", "message": "AMF log source is temporarily unavailable"},
                "evidence_refs": ["error:amf-log-source-unavailable"], "observed_at": now()}
    trial_dir = Path(state["trial_dir"])
    data = {
        "health": lambda: {"processes": process_view(state), "sessions": session_view(state)},
        "logs": lambda: {"gnb": tail(trial_dir / "gnb.log"), "ue": tail(trial_dir / "ue.log"),
                         "open5gs": core_logs(state)},
        "sessions": lambda: session_view(state),
        "processes": lambda: process_view(state),
        "pcap_summary": lambda: pcap_view(state),
        "connectivity": lambda: connectivity_view(state),
        "subscriber": subscriber_view,
        "metrics": lambda: metrics_view(state),
    }[capability]()
    return {"ok": True, "operation": "observe", "data": data,
            "evidence_refs": evidence_for(state, capability), "observed_at": now()}


def snapshot(request: dict) -> dict:
    state = require_active(request)
    return {"ok": True, "operation": "snapshot", "snapshot": {
        "trial_id": state["trial_id"], "scenario_id": state["scenario_id"], "fingerprint": state.get("fingerprint"),
        "processes": process_view(state), "sessions": session_view(state), "pcap": pcap_view(state), "captured_at": now(),
    }}


def reset(request: dict) -> dict:
    state = require_active(request)
    result = reset_baseline(state)
    reset_hash = digest({"baseline_ref": result["baseline_ref"], "verification": result["verification"]})
    STATE_FILE.unlink(missing_ok=True)
    return {"ok": result["ok"], "operation": "reset", "clean": result["clean"],
            "baseline_ref": result["baseline_ref"], "verification": result["verification"],
            "reset_hash": reset_hash, "reset_at": now()}


def health() -> dict:
    versions = {}
    for name, args in {
        "open5gs": ["open5gs-amfd", "-v"], "mongod": ["mongod", "--version"], "ueransim": [str(GNB_BINARY), "--version"],
    }.items():
        try:
            versions[name] = (run(args, timeout=8).stdout or "").splitlines()[0][:160]
        except Exception as error:
            versions[name] = f"unavailable: {error}"
    state = load_state()
    return {"ok": True, "operation": "health", "status": "ready" if GNB_BINARY.exists() and UE_BINARY.exists() else "not_ready",
            "active_trial": state.get("trial_id") if state else None, "versions": versions,
            "core": {name: service_active(name) for name in ["mongod", *CORE_SERVICES]},
            "baseline": baseline_verification() if state is None else None, "at": now()}


def validate_request(request: dict) -> None:
    operation = request.get("operation")
    if operation not in {"health", "prepare", "observe", "snapshot", "reset"}:
        raise ValueError("unsupported operation")
    if operation != "health" and not ID_RE.fullmatch(str(request.get("trial_id", ""))):
        raise ValueError("invalid trial_id")
    if operation == "prepare" and not ID_RE.fullmatch(str(request.get("scenario_id", ""))):
        raise ValueError("invalid scenario_id")


def dispatch(request: dict) -> dict:
    validate_request(request)
    return {"health": lambda _: health(), "prepare": prepare, "observe": observe,
            "snapshot": snapshot, "reset": reset}[request["operation"]](request)


def main() -> int:
    if os.geteuid() != 0:
        print(json.dumps({"ok": False, "error": "controller must run as root"}))
        return 1
    if len(sys.argv) != 3 or sys.argv[1] != "request":
        print(json.dumps({"ok": False, "error": "usage: opsmind-twinctl request <base64url-json>"}))
        return 2
    try:
        encoded = sys.argv[2] + "=" * (-len(sys.argv[2]) % 4)
        request = json.loads(base64.urlsafe_b64decode(encoded).decode("utf-8"))
        RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
        LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
        with LOCK_FILE.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            response = dispatch(request)
        print(json.dumps(response, ensure_ascii=False, separators=(",", ":")))
        return 0 if response.get("ok") else 3
    except PermissionError as error:
        print(json.dumps({"ok": False, "operation": request.get("operation") if 'request' in locals() else None,
                          "error": {"code": "TRIAL_SCOPE_MISMATCH", "message": str(error)}}))
        return 4
    except Exception as error:
        print(json.dumps({"ok": False, "operation": request.get("operation") if 'request' in locals() else None,
                          "error": {"code": "TWIN_CONTROLLER_ERROR", "message": str(error)[:500]}}))
        return 5


if __name__ == "__main__":
    raise SystemExit(main())
